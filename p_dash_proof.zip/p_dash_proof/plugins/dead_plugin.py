# This plugin defines NO pytest hooks
# Importing it succeeds, but it does nothing
X = 123
